import Component from "../kanban-board"

export default function Page() {
  return <Component />
}
